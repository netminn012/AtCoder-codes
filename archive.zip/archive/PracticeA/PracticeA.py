#aの入力
a= int(input())
#スペース区切りの整数の入力
b,c = map(int, input().split())
s = input()

#出力
print("{} {}".format(a+b+c,s))